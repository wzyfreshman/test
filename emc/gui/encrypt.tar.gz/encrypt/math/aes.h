#ifndef AES_H
#define AES_H

#include <openssl/aes.h>


char __PBNAME[] = "custom2";

unsigned char __PBAES_KEY[16] = {
    '@','1','2','3','2','r','g','h',
    '@','1','3','3','3','r','2','f'
};


#endif // AES_H
